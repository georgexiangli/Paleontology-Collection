package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class PaleontologyCollection {
  private Specimen[] myCollection;
  private static String filename;

  /**
   * Constructor for a paleontology collection
   * 
   * @param filename CSV data source
   */
  public PaleontologyCollection(String filename) {
    PaleontologyCollection.filename = filename;
    try {
      this.myCollection = parseCSV();
      for (int i = 0; i < 25; i++) {
        // System.out.println(myCollection[i].getSpecimenKey());
      }
    } catch (FileNotFoundException e) {
      System.out.println("File Not Found.");
    }
  }

  /**
   * Parses a CSV file
   * 
   * @return An array of specimens
   * @throws FileNotFoundException File not found
   */
  private static Specimen[] parseCSV() throws FileNotFoundException {
    Scanner csvScanner = new Scanner(new File(filename));
    String headerLine = csvScanner.nextLine();
    Specimen[] specimens = new Specimen[5000];

    //
    int count = 0;
    while (csvScanner.hasNextLine() && count < 25) {
      String row = csvScanner.nextLine();
      String[] data = row.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
      int specimenKey = Integer.parseInt(data[0]);
      int occurrenceKey = Integer.parseInt(data[3]);
      String specimenPart = data[9];
      String speciesName = data[19];
      double maxMa = Double.parseDouble(data[22]);
      double minMa = Double.parseDouble(data[23]);
      System.out.printf("%10d %10d %10s %35s %10.2f %10.2f\n", specimenKey, occurrenceKey,
          specimenPart, speciesName, maxMa, minMa);

      Specimen spc = new Specimen();
      spc.setSpecimenKey(specimenKey);
      spc.setOccurrenceKey(occurrenceKey);
      spc.setSpecimenPart(specimenPart);
      spc.setSpeciesName(speciesName);
      spc.setMaxMa(maxMa);
      spc.setMinMa(minMa);

      specimens[count] = spc;

      count++;
    }

    return specimens;
  }

  /**
   * Main method for testing
   * 
   * @param args command line arguments
   */
  public static void main(String[] args) {
    System.out.println("First 25 Specimens");
    System.out.printf("%10s %10s %10s %35s %10s %10s\n", "specimenKey", "occurrenceKey",
        "specimenPart", "speciesName", "maxMa", "minMa");
    PaleontologyCollection plc = new PaleontologyCollection("dinosaurData.csv");
  }

}
