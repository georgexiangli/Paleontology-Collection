package application;

import java.util.List;
import java.util.ArrayList;

public class BTree<V extends Comparable<V>> {
  private BTNode<V> root;
  private int bFactor;
  private int height;
  private int size;

  public BTree() {
    this.root = null;
    this.bFactor = 3;
    this.height = 0;
    this.size = 0;
  }

  private class BTNode<V extends Comparable<V>> {
    // private ArrayList<K> keys;
    private ArrayList<V> values;
    // private ArrayList<BTNode<V>> children;
    private BTNode<V> leftChild;
    private BTNode<V> middleChild;
    private BTNode<V> rightChild;
    private BTNode<V> tempChild; // for overloaded nodes
    private String tempPos;

    public BTNode() {
      // this.keys = new ArrayList<K>();
      this.values = new ArrayList<V>();
      this.tempPos = "";
//      this.children = new ArrayList<BTNode<V>>();
    }

    /**
     * Insert a key and value into a B-tree node
     * 
     * @param key
     * @param value
     */
    private void insertVal(V value) {
      // do a compare for sorted order
      // this.keys.add(key);
      for (int i = 0; i < this.values.size(); i++) {
        if (value.compareTo(this.values.get(i)) < 0) { 
          this.values.add(i, value);
          return;
        }
      }
      
      this.values.add(value);

    }
  }

  /**
   * Insert into a B-Tree, no duplicate keys allowed
   * 
   * @param key
   * @param value
   */
  public void insert(V value) {
    this.root = insert(value, this.root, null);
  }

  /**
   * Recursive helper method for insert
   * @param value
   * @param current
   * @param parent
   * @return
   */
  public BTNode<V> insert(V value, BTNode<V> current, BTNode<V> parent) {
    //TODO check for duplicates
    if (current == null) {
      current = new BTNode<V>();
      current.insertVal(value);
      return current;
    }
    
    // find the node
    // if else
    
    String insertedFrom = "";
    
    if (current.leftChild != null 
        || current.middleChild != null
        || current.rightChild != null) {
      boolean isRightChild = true;
      for (int i = 0; i < current.values.size(); i++) {
        if (value.compareTo(current.values.get(i)) < 0) {
          isRightChild = false;
          if (i == 0) {
            current.leftChild = insert(value, current.leftChild, current);
            insertedFrom = "left";
            break;
          } else if (i == 1) {
            current.middleChild = insert(value, current.middleChild, current);
            insertedFrom = "middle";
            break;
          }
        }
      }
      if (isRightChild) {
        current.rightChild = insert(value, current.rightChild, current);
        insertedFrom = "right";
      }
      
    } else { // leaf
      current.insertVal(value);
    }
    
    // node too big, make sure children are assigned correctly
    if (current.values.size() >= bFactor) {
      int splitIdx = bFactor / 2;
      V rightVal = current.values.remove(splitIdx + 1);
      
      BTNode<V> newRightChild = new BTNode<V>();
      newRightChild.insertVal(rightVal);
      
      boolean newRoot = false;
            
      V splitValue = current.values.remove(splitIdx);
      BTNode<V> newLeftChild = current;
      
      if (parent == null) {
        parent = new BTNode<V>();
        parent.leftChild = newLeftChild;
        if (current.tempPos.equals("leftRight")) {
          newRightChild.leftChild = current.middleChild;
          newRightChild.middleChild = current.rightChild;
          newLeftChild.middleChild = current.tempChild;
        }
        parent.middleChild = newRightChild;
        newLeftChild.tempChild = null;
        newLeftChild.rightChild = null;
        newRoot = true;
      }
      
      parent.insertVal(splitValue);
      
      // new root
      if (newRoot) {
        return parent;
      }
      
      
      // Resetting children
      BTNode<V> oldLeft = current.leftChild;
      BTNode<V> oldMid = current.middleChild;
      BTNode<V> oldRight = current.rightChild;
      
      // node overloaded due to insertion from lower node
      if (insertedFrom.equals("left")) {
        newLeftChild.leftChild = oldLeft;
        if (current.tempPos.equals("leftRight")) {
          newLeftChild.middleChild = current.tempChild;
        }
        newRightChild.leftChild = oldMid;
        newRightChild.middleChild = oldRight;
      }
      
      if (insertedFrom.equals("middle")
          || insertedFrom.contentEquals("right")) {
        newLeftChild.leftChild = oldLeft;
        newLeftChild.middleChild = oldMid;
        if (current.tempPos.equals("rightLeft")) {
          newRightChild.leftChild = current.tempChild;
        }
        newRightChild.middleChild = oldRight;
      }
      
      int insertedIdx = parent.values.indexOf(splitValue);
      
      // parent not overloaded
      if (parent.values.size() < bFactor) {
        if (insertedIdx == 0) {
          parent.rightChild = parent.middleChild;
          parent.middleChild = newRightChild;
        }
        
        if (insertedIdx == 1) {
          parent.middleChild = newLeftChild;
        }
        
      } else {
      
        // parent's right child
        if (insertedIdx == 2) {        
          parent.tempChild = newLeftChild;
          parent.tempPos = "rightLeft";
          return newRightChild;
        } else {
          parent.tempChild = newRightChild;
          if (insertedIdx == 0) {
            parent.tempPos = "leftRight";
          }
          
          if (insertedIdx == 1) {
            parent.tempPos = "rightLeft";
          }
        }
      }
      
    }
    
    return current;
  }

  /**
   * 
   */
  public void remove(int spcKey) {
    remove(spcKey, this.root, null);
  }
  
  
  
  private void remove(int spcKey, BTNode<V> current, BTNode<V> parent) {
    // key not found
    if (current == null) {
      return;
    }
    
  }

  /**
   * Return size of the B-tree
   * 
   * @return
   */
  public int size() {
    return size;
  }
  
  /**
   * Print a tree sideways to show structure. This code is completed for you.
   */
  public void printSideways() {
    System.out.println("------------------------------------------");
    recursivePrintSideways(this.root, "");
    System.out.println("------------------------------------------");
  }

  /**
   * Print nodes in a tree. This code is completed for you. You are allowed to modify this code to
   * include balance factors or heights
   * 
   * @param current
   * @param indent
   */
  private void recursivePrintSideways(BTNode<V> current, String indent) {
    if (current != null) {
      recursivePrintSideways(current.leftChild, indent + "    ");
      if (current.values.size() > 0) {
        System.out.println(indent + current.values.get(0));
      }
      recursivePrintSideways(current.middleChild, indent + "    ");
      if (current.values.size() > 1) {
        System.out.println(indent + current.values.get(1));
      }
      recursivePrintSideways(current.rightChild, indent + "    ");
    }
  }

  public static void main(String[] args) {
    BTree<Specimen> btree = new BTree<Specimen>();
    Specimen spc1 = new Specimen();
    spc1.setSpecimenKey(1000);
    spc1.setSpeciesName("Tyrannosaurus Rex");
    
    Specimen spc2 = new Specimen();
    spc2.setSpecimenKey(500);
    spc2.setSpeciesName("Velociraptor");
    
    Specimen spc3 = new Specimen();
    spc3.setSpecimenKey(1500);
    spc3.setSpeciesName("Stegosaurus");
    
    Specimen spc4 = new Specimen();
    spc4.setSpecimenKey(250);
    spc4.setSpeciesName("Diplodocus");

    Specimen spc5 = new Specimen();
    spc5.setSpecimenKey(100);
    spc5.setSpeciesName("Triceratops");
    
    Specimen spc6 = new Specimen();
    spc6.setSpecimenKey(50);
    spc6.setSpeciesName("Ankylosaurus");
    
    Specimen spc7 = new Specimen();
    spc7.setSpecimenKey(25);
    spc7.setSpeciesName("Coelophysis");

    Specimen spc8 = new Specimen();
    spc8.setSpecimenKey(30);
    spc8.setSpeciesName("Troodon");
    
    Specimen spc9 = new Specimen();
    spc9.setSpecimenKey(10);
    spc9.setSpeciesName("Edmontosaurus");

    Specimen spc10 = new Specimen();
    spc10.setSpecimenKey(5);
    spc10.setSpeciesName("Aptosaurus");

    Specimen spc11 = new Specimen();
    spc11.setSpecimenKey(35);
    spc11.setSpeciesName("Pachyrhinosaurus");

    Specimen spc12 = new Specimen();
    spc12.setSpecimenKey(40);
    spc12.setSpeciesName("Allosaurus");
    
    btree.insert(spc1);
    
    btree.insert(spc2);
    
    btree.insert(spc3);
    btree.insert(spc4);
    btree.insert(spc5);
    btree.insert(spc6);
    btree.insert(spc7);
    btree.insert(spc8);
    btree.insert(spc9);
    btree.insert(spc10);
    btree.insert(spc11);
    
    // Look at the Triceratops
//    btree.insert(spc12);
    
    btree.printSideways();
    // System.out.println(btree.root.values);
//    System.out.println("hello");
//    for (Specimen value : btree.root.values) {
//      System.out.println(value.getSpecimenKey());
//      System.out.println(value.getSpeciesName());
//    }
  }
  
}
