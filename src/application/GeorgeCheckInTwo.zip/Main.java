package application;
	
import java.io.FileInputStream;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;


public class Main extends Application {
	private static int endIdx;
    @Override
	public void start(Stage primaryStage) {
		try {
		    Specimen[] myArr = new Specimen[10];
		    
			VBox root = new VBox(8);
			
			// insert 
			TextField idField = new TextField("Specimen Key");
			TextField speciesField = new TextField("Species");
			TextField occurrenceField = new TextField("Occurrence Key");
			TextField partField = new TextField("Specimen Part");
			TextField maxMaField = new TextField("Maximum Ma");
			TextField minMaField = new TextField("Minimum Ma");
			
			Button insertButton = new Button("Insert");
			Label insertLabel = new Label("No specimens added yet");
			
			// remove
			TextField removeId = new TextField("Remove Specimen Key");
			
			Button removeButton = new Button("Remove");
			// Label removeLabel = new Label("No specimens removed yet");
			
			Button searchButton = new Button("Search");
			Button printButton = new Button("Print");
			Button exportButton = new Button("Export");
			
			final ImageView selectedImage = new ImageView(); 
			Image image1 = new Image(new FileInputStream("C:\\Users\\George Li\\Google Drive\\Computer Science\\Programming III\\Dinosaurs_Final\\src\\application\\trex.jpg"));
			selectedImage.setImage(image1);
			
			root.getChildren().addAll(
			    // insert fields
			    idField,
			    speciesField,
			    occurrenceField,
			    partField,
			    maxMaField,
			    minMaField,
			    insertButton, 
			    insertLabel,
			    
			    // remove fields
			    removeId,
			    removeButton, 
			    searchButton,
			    printButton,
			    exportButton,
			    selectedImage);
			
			insertButton.setOnAction(new EventHandler<ActionEvent>() {
	            @Override 
	            public void handle(ActionEvent e) {
	              // create specimen
	              Specimen insertSpc = new Specimen();
	              insertSpc.setSpecimenKey(Integer.parseInt(idField.getText()));
	              insertSpc.setSpeciesName(speciesField.getText());
	              insertSpc.setOccurrenceKey(Integer.parseInt(occurrenceField.getText()));
	              insertSpc.setSpecimenPart(partField.getText());
	              insertSpc.setMaxMa(Integer.parseInt(maxMaField.getText()));
	              insertSpc.setMinMa(Integer.parseInt(minMaField.getText()));
	              insertLabel.setText(insertSpc.getSpecimenKey() + " successfully added!");
	              
	              // insert
	              if (endIdx < myArr.length) {
	                myArr[endIdx] = insertSpc;
	                endIdx++;	                
	              }	              
	            }    
	        });
			
			removeButton.setOnAction(new EventHandler<ActionEvent>() {
			  @Override
			  public void handle(ActionEvent e) {
			    endIdx--;			    
			  }
			});
			
	        printButton.setOnAction(new EventHandler<ActionEvent>() {
              @Override 
              public void handle(ActionEvent e) {
                
                for (int i = 0; i < endIdx; i++) {
                  System.out.println(myArr[i]);
                }
                System.out.println("-----");
              }
            });
	        
			
			Scene scene = new Scene(root,800,900);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
